# Summer-Olympics-Data-Analysis
In this project we will go through the Summer Olympics Data  and do analysis of Gold medalist ,athletes,sport,City and Event 
### Intro to dataset
### link to kaggle datset: https://www.kaggle.com/divyansh22/summer-olympics-medals you can know more about data
* When the Olympics held (Year),
* Which city the sport is played by them,
* name of 43 Sports
* Athlete names
* their Country
* Their Gender
* what is the event about
### we have to analysis what is the data about 
#### to solve this problem i have used two library
* using import pandas as pd to read the data and perform operation on that
* import numpy as np to deal with array, matplotlib.pyplot to visualize data
*used two main function
-> df.groupby('Name') * to get the object containing name ,nameDataFrame where we perform different operation
-> df.panasSeries.value_counts() * to get the count of each value in that column
-> here i use bar plot to plot each data
* Solved Question
1. In how many cities Summer Olympics is held so far?
2. Which sport is having most number of Gold Medals so far? (Top 5)
3. Which sport is having most number of medals so far? (Top 5)
4. Which player has won most number of medals? (Top 5)
5. Which player has won most number Gold Medals of medals? (Top 5)
6. In which year India won first Gold Medal in Summer Olympics?
7. Which event is most popular in terms on number of players? (Top 5)
8. Which sport is having most female Gold Medalists? (Top 5)
 you can do all question by manual and using function i have explained in code
## About me
I am DHINESH KUMAR.G B.E in branch of  Electronics And Communcation .Learning Artificial intelegence ,Machine learning ,Computer Vision to utilze in the field of Robotics
#### link to follow

